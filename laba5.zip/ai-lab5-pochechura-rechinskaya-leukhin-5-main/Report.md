# Отчёт по лабораторной работе
## Генеративные текстовые нейросети

### Студенты: 

| ФИО       | Роль в проекте                     | Оценка       |
|-----------|------------------------------------|--------------|
| Почечура | Программировал SimpleRNN, писал отчёт |       |
| Речинская | Программировала трансферную архитектуру, писала отчёт |      |
| Леухин   | Программировал LSTM модели, писал отчёт |          |
| Сикорский   | Программировал дообучение предобученной GPT-сети, писал отчёт |          |

> *Комментарии проверяющего*

## 0. Датасет

В качестве датасета везде используются статьи с сайта Medium. Исходными данными является текст статей, а выходными данными - тег, определяющий тему статьи.


## 1. SimpleRNN

Для этого задания создаётся модель со следующей архитектурой: vectorizer (проводит разбиение входных данных по символам), слой Embedding и непосредственно слой SimpleRNN. В качестве функции активации используется RELU,
а для расчёта значения ошибки - Categorical Cross Entropy Loss. 

```python
model = keras.Sequential()
model.add(vectorizer)
model.add(layers.Embedding(input_dim=100000, output_dim=8))
model.add(layers.SimpleRNN(4))
model.add(layers.Dense(100, activation = 'relu'))
```

Код для обучения модели:

```python
model.compile(keras.optimizers.Adam(0.01), keras.losses.SparseCategoricalCrossentropy(from_logits=True), ['acc'])
train_model = model.fit(x=x, y=y, batch_size=32, epochs = 7, validation_data=(test_x, test_y))
```
Результат обучения:
![image](https://github.com/MAILabs-Edu-2023/ai-lab5-pochechura-rechinskaya-leukhin-5/assets/80180365/844f82c0-209a-48be-9e63-9bca41c94c9c)

Решение в файле [1Simple_RNN.ipynb](1Simple_RNN.ipynb)

## 2. LSTM

Решение в файле [2LSTM.ipynb](2LSTM.ipynb)

## 2.1. Однонаправленная однослойная LSTM

Архитектура модели для этого задания остаётся похожей, но вместо слоя SimpleRNN используется слой LSTM, и в качестве функции активации выступает гиперболический тангенс.

```python
model = keras.Sequential()
model.add(vectorizer)
model.add(layers.Embedding(input_dim=40000, output_dim=8, mask_zero=True))
model.add(layers.LSTM(4))
model.add(layers.Dense(100, activation = 'tanh'))
```

Код для обучения:

```python
model.compile(keras.optimizers.Adam(0.1), keras.losses.SparseCategoricalCrossentropy(from_logits=True), ['acc'])
train_model = model.fit(x=x, y=y, batch_size=64, epochs = 4, validation_data=(test_x, test_y))
```
Результат обучения:
![image](https://github.com/MAILabs-Edu-2023/ai-lab5-pochechura-rechinskaya-leukhin-5/assets/80180365/4d2c236e-31b9-4952-a03c-311733af1230)


## 2.2. Однонаправленная двуслойная LSTM

Отличие от однонаправленной однослойной LSTM заключается в том, что здесь используется два слоя LSTM.

```python
model = keras.Sequential()
model.add(vectorizer)
model.add(layers.Embedding(input_dim=40000, output_dim=64, mask_zero=True))
model.add(layers.LSTM(8, return_sequences=True))
model.add(layers.LSTM(4))
model.add(layers.Dense(100, activation = 'tanh'))
model.add(layers.Dense(100, activation = 'tanh'))
```

Код для обучения:

```python
model.compile(keras.optimizers.Adam(0.01), keras.losses.SparseCategoricalCrossentropy(from_logits=True), ['acc'])
train_model = model.fit(x=x, y=y, batch_size=64, epochs = 4, validation_data=(test_x, test_y))
```
Результат обучения:
![image](https://github.com/MAILabs-Edu-2023/ai-lab5-pochechura-rechinskaya-leukhin-5/assets/80180365/17499ff9-35b5-44d3-adec-be4d1d35086d)


## 2.3. Двунаправленная LSTM

Здесь используется слой Bidirectional, который "оборачивает" слой LSTM.

```python
model = keras.Sequential()
model.add(vectorizer)
model.add(layers.Embedding(input_dim=16000, output_dim=32, mask_zero=True))
model.add(layers.Bidirectional(keras.layers.LSTM(8), merge_mode='concat')),
model.add(layers.Dense(100, activation = 'tanh'))
```

Код для обучения:

```python
model.compile(keras.optimizers.Adam(0.1), keras.losses.SparseCategoricalCrossentropy(from_logits=True), ['acc'])
train_model = model.fit(x=x, y=y, batch_size=64, epochs = 4, validation_data=(test_x, test_y))
```
Результат обучения:
![image](https://github.com/MAILabs-Edu-2023/ai-lab5-pochechura-rechinskaya-leukhin-5/assets/80180365/321db0a3-e69a-4b96-bc81-1eb022298d70)


## 3. Трансформерная архитектура

Для выполнения этого задания использовалась библиотека keras nlp, представляющая широкий набор инструментов для решения задач NLP.
Описание модели:

```python
inputs = keras.layers.Input(shape=(None,), dtype=tf.int32)
embedding_layer = keras_nlp.layers.TokenAndPositionEmbedding(
    vocabulary_size=VOCAB_SIZE,
    sequence_length=SEQ_LEN,
    embedding_dim=EMBED_DIM,
    mask_zero=True,
)
x = embedding_layer(inputs)
for _ in range(NUM_LAYERS):
    decoder_layer = keras_nlp.layers.TransformerDecoder(
        num_heads=NUM_HEADS,
        intermediate_dim=FEED_FORWARD_DIM,
    )
    x = decoder_layer(x)  
outputs = keras.layers.Dense(VOCAB_SIZE)(x)
model = keras.Model(inputs=inputs, outputs=outputs)
loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)
perplexity = keras_nlp.metrics.Perplexity(from_logits=True, mask_token_id=0)
model.compile(optimizer="adam", loss=loss_fn, metrics=['acc'])
```

Обучение модели:
```python
model.fit(train_ds, validation_data=val_ds, verbose=2, epochs=EPOCHS)
```

Модель можно использовать для генерации текстов, используя обратный ход:

```python3
class TopKTextGenerator(keras.callbacks.Callback):
    def __init__(self, k):
        self.sampler = keras_nlp.samplers.TopKSampler(k)

    def on_epoch_end(self, epoch, logs=None):
        output_tokens = self.sampler(
            next=next,
            prompt=prompt_tokens,
            index=1,
        )
        txt = tokenizer.detokenize(output_tokens)
        print(f"Top-K search generated text: \n{txt}\n")


text_generation_callback = TopKTextGenerator(k=10)
model.fit(train_ds, verbose=2, epochs=2, callbacks=[text_generation_callback])
```

Пример работы:
![image](https://github.com/MAILabs-Edu-2023/ai-lab5-pochechura-rechinskaya-leukhin-5/assets/80180365/c03455ef-f79d-4d11-87f4-fe820b04eae9)

Решение в файле [3GPT.ipynb](3GPT.ipynb)

## 4. Дообучение предобученной GPT-сети

Описание модели:

```python
def train(train_file_path,model_name,
          output_dir,
          overwrite_output_dir,
          per_device_train_batch_size,
          num_train_epochs,
          save_steps):
  tokenizer = GPT2Tokenizer.from_pretrained(model_name)
  train_dataset = load_dataset(train_file_path, tokenizer)
  data_collator = load_data_collator(tokenizer)

  tokenizer.save_pretrained(output_dir)
      
  model = GPT2LMHeadModel.from_pretrained(model_name)

  model.save_pretrained(output_dir)

  training_args = TrainingArguments(
          output_dir=output_dir,
          overwrite_output_dir=overwrite_output_dir,
          per_device_train_batch_size=per_device_train_batch_size,
          num_train_epochs=num_train_epochs,
      )

  trainer = Trainer(
          model=model,
          args=training_args,
          data_collator=data_collator,
          train_dataset=train_dataset,
  )
      
  trainer.train()
  trainer.save_model()
```

Код для обучения:
```python
train_file_path = "Articles.txt"
model_name = 'gpt2'
output_dir = '/content/drive/MyDrive/result'
overwrite_output_dir = False
per_device_train_batch_size = 8
num_train_epochs = 5.0
save_steps = 500

train(
    train_file_path=train_file_path,
    model_name=model_name,
    output_dir=output_dir,
    overwrite_output_dir=overwrite_output_dir,
    per_device_train_batch_size=per_device_train_batch_size,
    num_train_epochs=num_train_epochs,
    save_steps=save_steps
)
    
```

Модель способна генерировать продолжение текста:

```python
def load_model(model_path):
    model = GPT2LMHeadModel.from_pretrained(model_path)
    return model


def load_tokenizer(tokenizer_path):
    tokenizer = GPT2Tokenizer.from_pretrained(tokenizer_path)
    return tokenizer


def generate_text(sequence, max_length):
    model_path = "/content/drive/MyDrive/result"
    model = load_model(model_path)
    tokenizer = load_tokenizer(model_path)
    ids = tokenizer.encode(f'{sequence}', return_tensors='pt')
    final_outputs = model.generate(
        ids,
        do_sample=True,
        max_length=max_length,
        pad_token_id=model.config.eos_token_id,
        top_k=50,
        top_p=0.95,
    )
    print(tokenizer.decode(final_outputs[0], skip_special_tokens=True))
```

Пример работы:
![image](https://github.com/MAILabs-Edu-2023/ai-lab5-pochechura-rechinskaya-leukhin-5/assets/80180365/c32a796e-2b58-4b74-b5d9-ea8c2a2b6cf5)


Решение в файле [4GPT2.ipynb](4GPT2.ipynb)
