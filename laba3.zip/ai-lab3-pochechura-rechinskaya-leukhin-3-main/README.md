[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=10795476&assignment_repo_type=AssignmentRepo)
# Лабораторная работа по курсу "Искусственный интеллект"
# Создание своего нейросетевого фреймворка

### Студенты: 

| ФИО       | Роль в проекте                     | Оценка       |
|-----------|------------------------------------|--------------|
| Почечура А.А. | Руководил |          |
| Леухин М.В. | Программировал |       |
| Речинская А.Ю. | Искала информацию |      |
| Сикорский А.А.   | Создавал github pages с документацией |          |

> *Комментарии проверяющего*

# [Документация заведена на github pages](https://sikorskii.github.io/docs/) 
